SwiftMC Store Web Files

Deployment Instructions for Vercel/GitHub:
1. Extract this ZIP file.
2. Upload the files exactly as they are to your GitHub repository (parshvgaming/SwiftMcWeb).
3. Ensure 'index.html', 'README.txt', and 'swiftmc-world-art.png' are in the root of the repository.
4. Go to Vercel.com, import this repository, and click Deploy.
